import React , { useContext } from 'react';
import styled from 'styled-components';
import { BoldLink, BoxContainer, FormContainer, Input, MutedLink, SubmitButton } from './common';
import { AccountContext } from "/home/sneha/Desktop/Login-Register/login/src/components/accountBox/accountContext";

const InnerContainer = styled.div`
width: 100%;
display: flex;
flex-direction: column;
padding: 1.8em;
`;

export function SignupForm(props){

    const { switchtoSignin } = useContext(AccountContext);

    return <BoxContainer>
        <FormContainer>
            <Input type="text" placeholder="Full Name"/>
            <Input type="username" placeholder="Username"/>
            <Input type="password" placeholder="Password"/>
            <Input type="password" placeholder="Confirm Password"/>
            </FormContainer>
            <MutedLink href="#">Forget Your Password</MutedLink>
            <SubmitButton type="submit">SignUp</SubmitButton>
            <MutedLink href="#">Already have an accont? 
                <BoldLink href="#" onClick={switchtoSignin}>SignIn</BoldLink>
            </MutedLink> 
    </BoxContainer>
}