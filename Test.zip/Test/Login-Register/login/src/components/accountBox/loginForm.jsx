import React , { useContext } from 'react';
import styled from 'styled-components';
import { AccountContext } from "/home/sneha/Desktop/Login-Register/login/src/components/accountBox/accountContext";
import { BoldLink, BoxContainer, FormContainer, Input, MutedLink, SubmitButton } from './common';

const InnerContainer = styled.div`
width: 100%;
display: flex;
flex-direction: column;
padding: 1.8em;
`;

export function LoginForm(props){
    
    const { switchtoSignup } = useContext(AccountContext);


    return <BoxContainer>
        <FormContainer>
            <Input type="username" placeholder="Username"/>
            <Input type="password" placeholder="Password"/> 
            </FormContainer>
            <MutedLink href="#">Forget Your Password</MutedLink>
            <SubmitButton type="submit">SignIn</SubmitButton>
            <MutedLink href="#">Don't have an account? 
                <BoldLink href="#" onClick={switchtoSignup}>SignUp</BoldLink>
            </MutedLink> 
    </BoxContainer>
}